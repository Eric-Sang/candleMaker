/**
 * Monday.com API helpers. All monday.api calls go through here.
 * Functions accept the monday SDK instance (from useMondayContext).
 */

/** Column title → id mapping. Your board should have columns with these exact titles for create order to work. */
export const ORDER_COLUMN_TITLES = {
  FIRST_NAME: "First name",
  LAST_NAME: "Last name",
  CANDLE_1: "Candle 1",
  CANDLE_2: "Candle 2",
  CANDLE_3: "Candle 3",
  INSCRIPTION: "Inscription",
};

/**
 * Fetch columns for a board (id, title, type).
 * @param {object} monday - monday SDK instance
 * @param {string} boardId - board ID
 * @returns {Promise<Array<{ id: string, title: string, type: string }>>}
 */
export async function getBoardColumns(monday, boardId) {
  if (!boardId) return [];
  const query = `
    query ($boardId: ID!) {
      boards(ids: [$boardId]) {
        columns { id title type }
      }
    }
  `;
  const res = await monday.api(query, { variables: { boardId } });
  const board = res?.data?.boards?.[0];
  return board?.columns ?? [];
}

/**
 * Build column_values object for one order line for create_item.
 * @param {Record<string, string>} columnIds - map of ORDER_COLUMN_TITLES key to column id
 * @param {object} payload - { firstName, lastName, option1, option2, option3, inscription }
 * @returns {object} column_values for Monday API
 */
function buildOrderLineColumnValues(columnIds, payload) {
  const values = {};
  if (columnIds.firstName)
    values[columnIds.firstName] = { text: payload.firstName || "" };
  if (columnIds.lastName)
    values[columnIds.lastName] = { text: payload.lastName || "" };
  if (columnIds.option1)
    values[columnIds.option1] = payload.option1
      ? { label: payload.option1 }
      : {};
  if (columnIds.option2)
    values[columnIds.option2] = payload.option2
      ? { label: payload.option2 }
      : {};
  if (columnIds.option3)
    values[columnIds.option3] = payload.option3
      ? { label: payload.option3 }
      : {};
  if (columnIds.inscription)
    values[columnIds.inscription] = { text: payload.inscription || "" };
  return values;
}

/**
 * Create Monday items for a full order (one item per order line).
 * @param {object} monday - monday SDK instance
 * @param {string} boardId - board ID
 * @param {Record<string, string>} columnIds - map of field key to column id (from mapBoardColumnsForOrder)
 * @param {string} firstName
 * @param {string} lastName
 * @param {Array<{ values: Array<{ label: string }|null>, inscription: string }>} orderRows
 * @returns {Promise<Array<{ id: string }>>} created items
 */
export async function createOrderItems(
  monday,
  boardId,
  columnIds,
  firstName,
  lastName,
  orderRows
) {
  const ids = Object.values(columnIds).filter(Boolean);
  if (!boardId || ids.length === 0 || orderRows.length === 0) {
    throw new Error("Missing board, column mapping, or order rows");
  }
  const created = [];
  for (let i = 0; i < orderRows.length; i++) {
    const row = orderRows[i];
    const itemName =
      [firstName, lastName].filter(Boolean).join(" ") +
        (orderRows.length > 1 ? ` - Line ${i + 1}` : "") || `Order ${i + 1}`;
    const columnValues = buildOrderLineColumnValues(columnIds, {
      firstName,
      lastName,
      option1: row.values[0]?.label ?? null,
      option2: row.values[1]?.label ?? null,
      option3: row.values[2]?.label ?? null,
      inscription: row.inscription ?? "",
    });
    const item = await createItem(monday, boardId, itemName, columnValues);
    if (item?.id) created.push(item);
  }
  return created;
}

/**
 * Map board columns to our order fields by title. Returns column id by field key.
 * @param {Array<{ id: string, title: string }>} columns
 * @returns {Record<string, string>} { firstName, lastName, option1, option2, option3, inscription } -> column id
 */
export function mapBoardColumnsForOrder(columns) {
  const titles = ORDER_COLUMN_TITLES;
  const byTitle = {};
  columns.forEach((col) => {
    byTitle[col.title] = col.id;
  });
  return {
    firstName: byTitle[titles.FIRST_NAME],
    lastName: byTitle[titles.LAST_NAME],
    option1: byTitle[titles.CANDLE_1],
    option2: byTitle[titles.CANDLE_2],
    option3: byTitle[titles.CANDLE_3],
    inscription: byTitle[titles.INSCRIPTION],
  };
}

/**
 * Fetch items from a board.
 * @param {object} monday - monday SDK instance
 * @param {string} boardId - board ID
 * @returns {Promise<Array>} items with id, name, column_values
 */
export async function getBoardItems(monday, boardId) {
  if (!boardId) return [];
  const query = `
    query ($boardId: ID!) {
      boards(ids: [$boardId]) {
        items_page(limit: 100) {
          items {
            id
            name
            column_values {
              id
              title
              text
              value
              type
            }
          }
        }
      }
    }
  `;
  const res = await monday.api(query, { variables: { boardId } });
  const board = res?.data?.boards?.[0];
  const items = board?.items_page?.items ?? [];
  return items;
}

/**
 * Create a new item on a board.
 * @param {object} monday - monday SDK instance
 * @param {string} boardId - board ID
 * @param {string} itemName - name of the item
 * @param {object} columnValues - map of column id to value (format depends on column type)
 * @returns {Promise<{ id: string }>}
 */
export async function createItem(monday, boardId, itemName, columnValues) {
  const query = `
    mutation ($boardId: ID!, $itemName: String!, $columnValues: JSON!) {
      create_item(board_id: $boardId, item_name: $itemName, column_values: $columnValues) {
        id
      }
    }
  `;
  const res = await monday.api(query, {
    variables: {
      boardId,
      itemName,
      columnValues: JSON.stringify(columnValues),
    },
  });
  return res?.data?.create_item;
}

/**
 * Update column values for an item.
 * @param {object} monday - monday SDK instance
 * @param {string} itemId - item ID
 * @param {string} boardId - board ID
 * @param {object} columnValues - map of column id to value
 * @returns {Promise<object>}
 */
export async function updateItem(monday, itemId, boardId, columnValues) {
  const query = `
    mutation ($boardId: ID!, $itemId: ID!, $columnValues: JSON!) {
      change_multiple_column_values(board_id: $boardId, item_id: $itemId, column_values: $columnValues) {
        id
      }
    }
  `;
  const res = await monday.api(query, {
    variables: {
      boardId,
      itemId,
      columnValues: JSON.stringify(columnValues),
    },
  });
  return res?.data?.change_multiple_column_values;
}
