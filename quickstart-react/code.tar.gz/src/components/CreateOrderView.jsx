import React, { useRef, useState, useEffect } from "react";
import { TextField, Button, Text } from "@vibe/core";
import { OrderRow } from "./OrderRow";
import {
  getBoardColumns,
  mapBoardColumnsForOrder,
  createOrderItems,
} from "../services/mondayApi";

export function CreateOrderView({ monday, boardId }) {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [orderRows, setOrderRows] = useState([]);
  const [columnIds, setColumnIds] = useState(null);
  const [submitStatus, setSubmitStatus] = useState(null);
  const [submitError, setSubmitError] = useState(null);
  const nextOrderIdRef = useRef(0);

  useEffect(() => {
    if (!boardId || !monday) return;
    let cancelled = false;
    getBoardColumns(monday, boardId)
      .then((cols) => {
        if (!cancelled) setColumnIds(mapBoardColumnsForOrder(cols));
      })
      .catch(() => {
        if (!cancelled) setColumnIds({});
      });
    return () => { cancelled = true; };
  }, [monday, boardId]);

  const handleAddOrder = () => {
    const id = nextOrderIdRef.current++;
    setOrderRows((prev) => [...prev, { id, values: [null, null, null], inscription: "" }]);
    setFirstName("");
    setLastName("");
  };

  const handleDropdownChange = (rowId, dropdownIndex, option) => {
    setOrderRows((prev) =>
      prev.map((row) =>
        row.id === rowId
          ? { ...row, values: [...row.values.slice(0, dropdownIndex), option, ...row.values.slice(dropdownIndex + 1)] }
          : row
      )
    );
  };

  const handleRemoveOrder = (rowId) => {
    setOrderRows((prev) => prev.filter((row) => row.id !== rowId));
  };

  const handleInscriptionChange = (rowId, value) => {
    setOrderRows((prev) =>
      prev.map((row) => (row.id === rowId ? { ...row, inscription: value } : row))
    );
  };

  // @vibe/core TextField may call onChange(value) or onChange(event) – normalize to string
  const getTextFieldValue = (e) =>
    (e?.target?.value !== undefined ? e.target.value : (typeof e === "string" ? e : "")) ?? "";

  const handleSubmit = async () => {
    if (orderRows.length === 0) {
      setSubmitStatus("error");
      setSubmitError("Add at least one order line.");
      return;
    }

    // When not on a board: save to localStorage so View orders can show it (dev/demo)
    if (!boardId || !monday) {
      try {
        const payload = {
          firstName,
          lastName,
          orderRows: orderRows.map((row) => ({
            values: row.values.map((v) => (v ? { label: v.label, value: v.value } : null)),
            inscription: row.inscription ?? "",
          })),
          submittedAt: new Date().toISOString(),
        };
        localStorage.setItem("candleOrdersDev", JSON.stringify(payload));
        setSubmitStatus("success");
        setOrderRows([]);
        setFirstName("");
        setLastName("");
      } catch {
        setSubmitStatus("error");
        setSubmitError("Open this app on a board to create orders.");
      }
      return;
    }

    const hasMapping = columnIds && Object.values(columnIds).some(Boolean);
    if (!hasMapping) {
      setSubmitStatus("error");
      setSubmitError('Board must have columns: "First name", "Last name", "Candle 1", "Candle 2", "Candle 3", "Inscription".');
      return;
    }

    setSubmitStatus("loading");
    setSubmitError(null);
    try {
      await createOrderItems(monday, boardId, columnIds, firstName, lastName, orderRows);
      setSubmitStatus("success");
      setOrderRows([]);
      setFirstName("");
      setLastName("");
    } catch (err) {
      setSubmitStatus("error");
      setSubmitError(err?.message ?? "Failed to create orders.");
    }
  };

  return (
    <>
      <section className="order-form">
        <div className="order-form-field">
          <TextField
            size="small"
            placeholder="First name"
            value={firstName}
            onChange={(e) => setFirstName(getTextFieldValue(e))}
          />
        </div>
        <div className="order-form-field">
          <TextField
            size="small"
            placeholder="Last name"
            value={lastName}
            onChange={(e) => setLastName(getTextFieldValue(e))}
          />
        </div>
        <Button className="order-form-add-btn" size="small" onClick={handleAddOrder}>
          Add order
        </Button>
      </section>
      <section className="order-rows">
        {orderRows.map((row, rowIndex) => (
          <OrderRow
            key={row.id}
            row={row}
            rowIndex={rowIndex}
            onDropdownChange={handleDropdownChange}
            onInscriptionChange={handleInscriptionChange}
            onRemove={handleRemoveOrder}
          />
        ))}
      </section>
      <section className="order-submit">
        {submitStatus === "error" && submitError && (
          <Text type="text2" color="negative" className="order-submit-message">{submitError}</Text>
        )}
        {submitStatus === "success" && (
          <Text type="text2" color="positive" className="order-submit-message">Orders created.</Text>
        )}
        <Button onClick={handleSubmit} disabled={submitStatus === "loading"}>
          {submitStatus === "loading" ? "Creating…" : "Submit"}
        </Button>
      </section>
    </>
  );
}
